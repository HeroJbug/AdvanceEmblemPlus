---------- ~ ADVANCE EMBLEM + ~ ----------
Created by: Jackson Hutson


How to run "Advance Emblem +":
	- 1. Install BreezySwing
		- instructions here: https://lambertk.academic.wlu.edu/breezyswing/installing-breezyswing/
	- 2. Run the game in Command Prompt with the following Command:
		- java -jar AdvanceEmblem+.jar
	- 3. Enjoy!